#include <stdio.h>
#include <stdlib.h>

int main()
{
    FILE *fp;
    char c;
    int n;
    float f;

    fp = fopen("Datos.txt", "w"); /* apertura en modo ecritura */
    if(fp != NULL)
    {
        printf("Apertura ok\n");
        /* operaciones de escritura */
        c = 'A';
        n = 100;
        f = 34.57;

        /* escribir un sólo caracter por vez con fputc() */
        fputc(c, fp);
        fputc('\n', fp);

        /* escribir un número entero con fprintf() */
        fprintf(fp, "Numero: %d\n", n);

        /* escribir un número real con fprintf() */
        fprintf(fp, "Precio: %.2f\n", f);

        fclose(fp); /* cierre del archivo */
        printf("Archivo Datos.txt generado correctamente.\n");
    }
    else{
        printf("Error de apertura\n");
    }

    return 0;
}